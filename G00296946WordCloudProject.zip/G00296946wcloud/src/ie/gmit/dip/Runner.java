package ie.gmit.dip;

/**
 * HDip /**H.Dip in Science (Software Development) Advanced OOSD Department of
 * Computer Science & Applied Physics, GMIT
 * 
 * @author Valery Taustsiakou 
 * @Class Runner runs the Menu Class
 */

public class Runner {

	public static void main(String[] args) throws Exception {
		Menu.runMenu();
	}
}
